/* Yousef Elsayed G01259710
 * lab section 215 
 * Lab: askes for input and uses control flow 
*/




#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>







void printmen(){
        printf("Enter/Change Character\t\'C\' or \'c\'\nEnter/Change Number\t\'N\' or \'n\'\nPrint Plus (+) Figure\t\'1\'\nPrint (X) Figure\t\'2\'\nQuit Program\t\'Q\' or \'q\'\n");
}



char usethis(){
	char k[10];
	char p;
	printf("Enter in your choice: ");
	fgets(k, 10, stdin);
	sscanf(k, "%c", &p);
	return p;

}



int useThisNum(){

	char chars[5];
	int numb = 0;
	printf("Enter a Number Between 3 - 15 ");

	fgets(chars, 5, stdin);
	sscanf(chars, "%d", &numb);
	fflush(stdin);	

	while((numb <  3 || numb > 15)){
		char chas[5];
		printf("The value is not within 3 - 15 reenter please\n");
		fgets(chas, 5, stdin);
		sscanf(chas, "%d", &numb);
	
	}	

	return numb;

}



void PrintX(int N, char C){
	int i;
	int k;

	for(i = 0; i < N; i++){
		for(k = 0; k < N; k++){
			if(i == k || i+k == N-1){
				printf("%c",C);
			}
			else{
				printf(" ");
			}	
			
			
		}

		printf("\n");	
	
	}


}

void PrintPlus(int N, char C){
		
	int i;
	int k;	


	for(i = 0; i <= N; i++){
		for(k = 0; k <= N; k++){
			if(i == (N/2) +1 || k == (N/2) +1){
				printf("%c",C);
			}
			else
			{
				printf(" ");

			}
		}
		printf("\n");
	}

		

}







int main(){
	char C = ' ';
	int N = 0;
	char p = ' ';
	  printmen();	
	C = usethis();


	while(C != 'q' ||C != 'Q'){
		
		

		if(C == 'C' ||C == 'c'){
			printf("you will now be changing the character\n");
			p = usethis();
		}
		else if(C == 'n' ||C == 'N'){

			printf("You are channging the number\n");
			N = useThisNum();
		}	
		else if(C == '1'){
			if(N == 0){
				N = useThisNum();
				PrintPlus(N,p);
			}
			else{
				
				PrintPlus(N,p);
				}
		}
		else if(C == '2'){
			if(N == 0){
                                N = useThisNum();
				PrintX(N,p);
			}
                        else{
				PrintX(N,p);
				}
		}

		else if(C == 'q' || C == 'Q' || p == 'q' || p == 'Q'){
			printf("The program was Exited\n");
			exit(0);

		}

		
		else{
			printf("Not a valid Choice, Reenter\n");
		}



			printmen();

			C = usethis();
		}

		return 0;
	}
