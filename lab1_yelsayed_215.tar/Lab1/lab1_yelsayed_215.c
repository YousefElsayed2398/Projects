/*
 * Yousef Elsayed
 * CS 262,Lab Section 215
 */

#include <stdio.h>

int main(){
	char name[100] = "Yousef Elsayed";
	printf("Hello World!\nMy name is %s\n", name);
	return 0;
}
