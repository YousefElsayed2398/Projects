
/* Yousef Elsayed G01259710
 * CS 262, Lab Section 215 Lab 2
 * lab 2: BSA calculator
 */





#include <stdio.h>
#include <math.h>



/*Twc = 0.007184 * W0.425 * H0.725*/
#define BSA(w, h) (pow(w,.425) * pow(h,.725) *.007184)
int main()
{


    double height;
    double weight;
    char inpt[100];

    printf("what is your height and weight");


    	
        fgets(inpt, 50, stdin);

        sscanf(inpt, "%lf %lf", &weight,&height);

        printf("The height is: %f\n", height);
        printf("The weight is: %f\n", weight);
    	printf("The BSA is:  %.4f\n", BSA(height, weight));






}

