/* Yousef Elsayed G01259710
 * Lab 4: section 215
 * Lab 4: Clock Lab
 */


#include <stdio.h>
#include <stdlib.h>



int Ang(int H, int M){
    int Ang;
   Ang = ((60 - M) + (H * 5) + (M/12))*6;
        while(Ang > 180){
            Ang -= 360;
        }
    return Ang;
}

int Anhelper(int H, int M){
        int Ang;
        Ang = abs((H * 30 + (M/12) * 6) - (M * 6));
        while(Ang>180)
                Ang -= 360;
        return Ang;
}


int getAng(){
     char v[10];
        char c[10];
        int x;
        printf("Enter an angle 0 - 180: \n");
        fgets(c, 10, stdin);
        sscanf(c, "%d", &x);
        while(x < 0|| x > 180){
        printf("The entered Angle is not in range of 0 - 180, please re-enter angle: \n");
        fgets(v, 10,stdin);
        sscanf(v,"%d", &x);
        }
    return x;
}


int main() {
    int H,M,Num=0,angl = getAng();

    for(H = 0; H <12; H++){
        for(M = 0; M < 60; M++){
            if(angl == Ang(H,M) || angl == Anhelper(H,M)){
                Num++;
                printf("Regular Hr %d:%d   Military Hr %d:%d\n",H,M,H+12,M);
            }
        }
    }
    if(Num == 0){
	  printf("There is no hour where the hands are A degrees apart");
    }
    else{
	  printf("%d is how many times angle (%d) occurs", 2*Num, angl);
    }
    
    return 0;
}












